using System.Drawing;
using System.Windows.Forms;

namespace WindowsSystemDialogTemplate;

/// <summary>
/// Reusable WinForms recreation of the classic Windows information/warning/error dialog layout.
/// The non-client frame/title bar is left to Windows so it follows the user's current OS theme.
/// </summary>
public sealed class WindowsMessageDialog : Form
{
    // 96-DPI design metrics, based on the classic Windows 7-era message/task dialog layout.
    private const int MinimumClientWidth = 508;
    private const int MaximumClientWidth = 680;
    private const int ContentLeft = 18;
    private const int ContentRight = 18;
    private const int ContentTop = 15;
    private const int IconSize = 32;
    private const int IconTextGap = 14;
    private const int HeadingBodyGap = 12;
    private const int ContentBottom = 17;
    private const int FooterHeight = 49;
    private const int ButtonWidth = 75;
    private const int ButtonHeight = 23;
    private const int ButtonRight = 18;
    private const int ButtonBottom = 13;

    // Classic Windows task-dialog main-instruction blue.
    private static readonly Color MainInstructionColor = Color.FromArgb(0, 51, 153);
    private static readonly Color FooterColor = Color.FromArgb(240, 240, 240);
    private static readonly Color SeparatorColor = Color.FromArgb(223, 223, 223);

    private readonly PictureBox _iconBox;
    private readonly Label _headingLabel;
    private readonly Label _messageLabel;
    private readonly Panel _footerPanel;
    private readonly Button _closeButton;
    private readonly Font _headingFont;

    public WindowsMessageDialog(
        string title,
        string heading,
        string message,
        DialogKind kind = DialogKind.Information,
        string buttonText = "OK")
    {
        ArgumentNullException.ThrowIfNull(title);
        ArgumentNullException.ThrowIfNull(heading);
        ArgumentNullException.ThrowIfNull(message);
        ArgumentNullException.ThrowIfNull(buttonText);

        SuspendLayout();

        Text = title;
        Font = SystemFonts.MessageBoxFont;
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96F, 96F);
        BackColor = Color.White;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowIcon = false;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        KeyPreview = true;

        // The classic "main instruction" is slightly larger than normal body text,
        // but intentionally not bold.
        _headingFont = new Font(Font.FontFamily, Font.Size + 1.5F, FontStyle.Regular, GraphicsUnit.Point);

        _iconBox = new PictureBox
        {
            BackColor = Color.Transparent,
            Location = new Point(ContentLeft, ContentTop),
            Size = new Size(IconSize, IconSize),
            SizeMode = PictureBoxSizeMode.CenterImage,
            TabStop = false,
            Image = GetDialogIcon(kind).ToBitmap()
        };

        _headingLabel = new Label
        {
            AutoSize = false,
            BackColor = Color.Transparent,
            Font = _headingFont,
            ForeColor = MainInstructionColor,
            Text = heading,
            UseCompatibleTextRendering = false
        };

        _messageLabel = new Label
        {
            AutoSize = false,
            BackColor = Color.Transparent,
            Font = Font,
            ForeColor = SystemColors.ControlText,
            Text = message,
            UseCompatibleTextRendering = false
        };

        _footerPanel = new Panel
        {
            BackColor = FooterColor,
            Dock = DockStyle.Bottom,
            Height = FooterHeight
        };
        _footerPanel.Paint += FooterPanel_Paint;

        _closeButton = new Button
        {
            AutoSize = false,
            DialogResult = DialogResult.OK,
            FlatStyle = FlatStyle.System,
            Size = new Size(ButtonWidth, ButtonHeight),
            Text = buttonText,
            UseVisualStyleBackColor = true
        };

        _footerPanel.Controls.Add(_closeButton);
        Controls.Add(_iconBox);
        Controls.Add(_headingLabel);
        Controls.Add(_messageLabel);
        Controls.Add(_footerPanel);

        AcceptButton = _closeButton;
        CancelButton = _closeButton;

        LayoutDialog();
        ResumeLayout(false);
    }

    public static DialogResult Show(
        IWin32Window? owner,
        string title,
        string heading,
        string message,
        DialogKind kind = DialogKind.Information,
        string buttonText = "OK")
    {
        using var dialog = new WindowsMessageDialog(title, heading, message, kind, buttonText);
        return owner is null ? dialog.ShowDialog() : dialog.ShowDialog(owner);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _iconBox.Image?.Dispose();
            _headingFont.Dispose();
        }

        base.Dispose(disposing);
    }

    private void LayoutDialog()
    {
        var textLeft = ContentLeft + IconSize + IconTextGap;

        // Prefer the classic compact width, but allow long text to make the dialog wider
        // before wrapping aggressively.
        var longestLine = Math.Max(
            MeasureNaturalWidth(_headingLabel.Text, _headingFont),
            MeasureNaturalWidth(_messageLabel.Text, Font));

        var desiredClientWidth = Math.Clamp(
            textLeft + longestLine + ContentRight,
            MinimumClientWidth,
            MaximumClientWidth);

        var textWidth = desiredClientWidth - textLeft - ContentRight;

        var headingSize = TextRenderer.MeasureText(
            _headingLabel.Text,
            _headingFont,
            new Size(textWidth, int.MaxValue),
            TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.TextBoxControl);

        var bodySize = TextRenderer.MeasureText(
            _messageLabel.Text,
            Font,
            new Size(textWidth, int.MaxValue),
            TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.TextBoxControl);

        var headingHeight = Math.Max(_headingFont.Height, headingSize.Height);
        var bodyTop = ContentTop + headingHeight + HeadingBodyGap;
        var bodyHeight = Math.Max(Font.Height, bodySize.Height);

        var contentHeight = Math.Max(
            ContentTop + IconSize + ContentBottom,
            bodyTop + bodyHeight + ContentBottom);

        ClientSize = new Size(desiredClientWidth, contentHeight + FooterHeight);

        _headingLabel.SetBounds(textLeft, ContentTop - 1, textWidth, headingHeight + 2);
        _messageLabel.SetBounds(textLeft, bodyTop, textWidth, bodyHeight + 2);

        _closeButton.Location = new Point(
            _footerPanel.ClientSize.Width - ButtonRight - ButtonWidth,
            _footerPanel.ClientSize.Height - ButtonBottom - ButtonHeight);
        _closeButton.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
    }

    private static int MeasureNaturalWidth(string text, Font font)
    {
        var lines = text.Replace("\r", string.Empty).Split('\n');
        var width = 0;

        foreach (var line in lines)
        {
            var measured = TextRenderer.MeasureText(
                string.IsNullOrEmpty(line) ? " " : line,
                font,
                Size.Empty,
                TextFormatFlags.NoPadding | TextFormatFlags.SingleLine);

            width = Math.Max(width, measured.Width);
        }

        return width;
    }

    private static Icon GetDialogIcon(DialogKind kind) => kind switch
    {
        DialogKind.Information => SystemIcons.Information,
        DialogKind.Warning => SystemIcons.Warning,
        DialogKind.Error => SystemIcons.Error,
        _ => SystemIcons.Information
    };

    private static void FooterPanel_Paint(object? sender, PaintEventArgs e)
    {
        using var pen = new Pen(SeparatorColor);
        e.Graphics.DrawLine(pen, 0, 0, e.ClipRectangle.Right, 0);
    }
}
