# Windows System Dialog Template

A small .NET 8 WinForms project that recreates the classic Windows information / warning / error message layout rather than using a normal `MessageBox`.

## What is matched

- Native Windows title bar / non-client frame
- White content area
- `#003399` main-instruction text
- System message-box font for body text
- Slightly larger non-bold main instruction
- 32x32 native Windows Information / Warning / Error icons
- Classic 18 px outer margins, 14 px icon-to-text gap, and compact vertical spacing
- `#F0F0F0` command area with a `#DFDFDF` top separator
- Classic 75x23 system-style command button
- DPI-aware scaling
- Automatic text wrapping and dialog-height calculation

The title bar deliberately follows the current version of Windows. On Windows 11 it will therefore use Windows 11 chrome; on an older Windows version it will use that version's chrome. The client-area layout is the classic template.

## Open in Visual Studio

Open `WindowsSystemDialogTemplate.sln`, or open the `.csproj` directly.

Requirements: Visual Studio 2022 with the .NET desktop development workload and .NET 8 SDK.

## Reuse

Copy `WindowsMessageDialog.cs` and `DialogKind.cs` into another WinForms project, then call:

```csharp
WindowsMessageDialog.Show(
    this,
    "Low Battery",
    "Change your battery or switch to outlet power immediately",
    "Your computer has a low battery, so you should act immediately to keep from losing your work.",
    DialogKind.Warning,
    "Close");
```
