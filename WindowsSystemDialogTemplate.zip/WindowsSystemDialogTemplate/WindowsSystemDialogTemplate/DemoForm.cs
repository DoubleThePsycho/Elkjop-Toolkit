using System.Drawing;
using System.Windows.Forms;

namespace WindowsSystemDialogTemplate;

public sealed class DemoForm : Form
{
    public DemoForm()
    {
        Text = "Windows Dialog Template Demo";
        Font = SystemFonts.MessageBoxFont;
        AutoScaleMode = AutoScaleMode.Dpi;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(390, 170);
        MinimumSize = Size;
        MaximizeBox = false;

        var infoButton = CreateButton("Information", 20);
        var warningButton = CreateButton("Warning", 65);
        var errorButton = CreateButton("Error", 110);

        infoButton.Click += (_, _) => WindowsMessageDialog.Show(
            this,
            "Information",
            "The operation completed successfully",
            "Windows has finished processing your request.",
            DialogKind.Information,
            "Close");

        warningButton.Click += (_, _) => WindowsMessageDialog.Show(
            this,
            "Low Battery",
            "Change your battery or switch to outlet power immediately",
            "Your computer has a low battery, so you should act immediately to keep from losing your work.",
            DialogKind.Warning,
            "Close");

        errorButton.Click += (_, _) => WindowsMessageDialog.Show(
            this,
            "Application Error",
            "Windows could not complete the requested operation",
            "An unexpected error occurred. Check the information you entered and try again.",
            DialogKind.Error,
            "Close");

        Controls.AddRange([infoButton, warningButton, errorButton]);
    }

    private static Button CreateButton(string text, int top) => new()
    {
        Text = text,
        Size = new Size(150, 30),
        Location = new Point(20, top),
        FlatStyle = FlatStyle.System,
        UseVisualStyleBackColor = true
    };
}
