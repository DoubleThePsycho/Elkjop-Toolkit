namespace WindowsSystemDialogTemplate;

public enum DialogKind
{
    Information,
    Warning,
    Error
}
